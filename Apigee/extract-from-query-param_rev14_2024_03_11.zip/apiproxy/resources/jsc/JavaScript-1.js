 var s=context.getVariable("request.queryparam.username")
 
 context.setVariable("request.queryparam.username",firstName)